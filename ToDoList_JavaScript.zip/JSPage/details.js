//list type
let mytodolist = document.getElementsByTagName("div");
//close btn
let close = document.getElementsByClassName("close");

// Create a new list item when clicking on the "Add" button
function newElement() {
  // create element
  let div = document.createElement("div");
  let txt = document.createElement("button");
  let span = document.createElement("div");
  let img = document.createElement("img");
  let textValue = document.createElement("a");
  let inputValue = document.getElementById("myInput").value;

  if (inputValue === "") {
    alert("You must write something!");
  } else {
    document.getElementById("myUL").appendChild(div);
  }
  //after input value input bar default position 
  document.getElementById("myInput").value = "";

  // styles
  img.src = "https://picsum.photos/200/300";
  txt.innerHTML = "X";
  span.className = "close";
  div.className = "box_create";
  img.className = "img_size";
  textValue.className = "text_size";
  textValue.href="TodoItems.html"
  textValue.id="text_val"
  textValue.innerHTML = inputValue;

  //appendchile
  span.appendChild(txt);
  div.appendChild(img);
  div.appendChild(span);
  div.appendChild(textValue);
  
  // store local storage
  localStorage.setItem("myInput",inputValue)

  //dlt todo
  for (i = 0; i < close.length; i++) {
    close[i].onclick = function () {
      let div = this.parentElement;
      div.style.display = "none";
    };
  }
}
