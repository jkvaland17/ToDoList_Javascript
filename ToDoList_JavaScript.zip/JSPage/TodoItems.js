// //get localstorage data
// let storeInput = localStorage.getItem("myInput");
// document.getElementById("Meeting_name").innerHTML = storeInput;
// document.getElementById("Todo_name").innerHTML = storeInput;

// //crete to do
// //list type
// let mytodolist = document.getElementsByTagName("LI");

// //close btn
// let close = document.getElementsByClassName("close");
// // Create a new list item when clicking on the "Add" button
// function newElement() {
//   let li = document.createElement("li");
//   let inputValue = document.getElementById("myInput").value;
//   let t = document.createTextNode(inputValue);
//   li.appendChild(t);
//   if (inputValue === "") {
//     alert("You must write something!");
//   } else {
//     document.getElementById("Todo_list").appendChild(li);
//   }
//   document.getElementById("myInput").value = "";

//   let span = document.createElement("SPAN");
//   let txt = document.createElement("button");
//   txt.innerHTML = "X";
//   span.className = "close";
//   span.appendChild(txt);
//   li.appendChild(span);

//   for (i = 0; i < close.length; i++) {
//     close[i].onclick = function () {
//       let div = this.parentElement;
//       div.style.display = "none";
//     };
//   }
// }

// //remove div
// function removeAll() {
//   let lst = document.getElementsByClassName("Todo");
//   lst[0].innerHTML = "";
// }

///////////////////////////////////////////////////////////////
// //get localstorage data
let storeInput = localStorage.getItem("myInput");
document.getElementById("Meeting_name").innerHTML = storeInput;

//rigt-side todo
//list type
let Right_mytodolist = document.getElementsByTagName("div");

//close btn
let close = document.getElementsByClassName("close");

// Create a new list item when clicking on the "Add" button
function newElement() {
  // create element
  let div = document.createElement("div");
  let txt = document.createElement("button");
  let span = document.createElement("div");
  let textValue = document.createElement("div");
  let inputValue = document.getElementById("Right_myInput").value;

  if (inputValue === "") {
    alert("You must write something!");
  } else {
    document.getElementById("Right_myUL").appendChild(div);
  }

  //after input value input bar default position
  document.getElementById("Right_myInput").value = "";

  // styles
  txt.innerHTML = "X";
  span.className = "close";
  div.className = "box_create";
  div.id = "remove_box";
  textValue.className = "Left_text_size";
  textValue.id = "text_val";
  textValue.innerHTML =
    inputValue +
    `<div class="To_Left_input">
  <input type="text" placeholder="ADD A LIST" id="Left_input" class ="Left_input" />
  <button class="add_value" onClick="add_value(this)"  ><i class="fa-solid fa-plus"></i></button>
</div>`;

  //appendchile
  span.appendChild(txt);
  div.appendChild(span);
  div.appendChild(textValue);

  //dlt todo
  for (i = 0; i < close.length; i++) {
    close[i].onclick = function () {
      let div = this.parentElement;
      div.style.display = "none";
    };
  }
}

//iner todo box
function add_value(e) {
  let input_val = e.closest("div").querySelector("input").value;
  let div1 = document.createElement("div");
  let inputs =document.querySelectorAll(".Left_input")
  for (let input of inputs) {
    input.value = ""
  }
  div1.className = "d_flex";
  div1.innerHTML = ` <p>${input_val}</p>
    <button class="add_value" onClick="delete_val(this)"><i class="fa-regular fa-circle-xmark"></i></button>`;
  e.closest(".Left_text_size").appendChild(div1);
}
//dlt value inner list
function delete_val(e) {
  e.closest("div").remove();
}



